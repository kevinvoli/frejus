import { AppShell, Burger, Button, Group, NavLink as MantineNavLink, Text, Title } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import {
  IconLogout,
  IconMessage,
  IconMessageCircle,
  IconPhoto,
  IconSettings,
  IconStar,
} from '@tabler/icons-react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

const NAV_ITEMS = [
  { to: '/settings', label: 'Réglages du site', icon: IconSettings },
  { to: '/specialties', label: 'Spécialités', icon: IconStar },
  { to: '/portfolio', label: 'Portfolio', icon: IconPhoto },
  { to: '/testimonials', label: 'Témoignages', icon: IconMessage },
  { to: '/contact-messages', label: 'Messages de contact', icon: IconMessageCircle },
];

export function AppLayout() {
  const [opened, { toggle }] = useDisclosure();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  function handleLogout() {
    logout();
    navigate('/login', { replace: true });
  }

  return (
    <AppShell
      header={{ height: 60 }}
      navbar={{ width: 260, breakpoint: 'sm', collapsed: { mobile: !opened } }}
      padding="md"
    >
      <AppShell.Header>
        <Group h="100%" px="md" justify="space-between">
          <Group>
            <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
            <Title order={3}>Pixellia — Administration</Title>
          </Group>
          <Group>
            {user && (
              <Text size="sm" c="dimmed">
                {user.email}
              </Text>
            )}
            <Button variant="subtle" leftSection={<IconLogout size={16} />} onClick={handleLogout}>
              Déconnexion
            </Button>
          </Group>
        </Group>
      </AppShell.Header>
      <AppShell.Navbar p="md">
        {NAV_ITEMS.map((item) => (
          <MantineNavLink
            key={item.to}
            component={NavLink}
            to={item.to}
            label={item.label}
            leftSection={<item.icon size={18} />}
            active={location.pathname.startsWith(item.to)}
          />
        ))}
      </AppShell.Navbar>
      <AppShell.Main>
        <Outlet />
      </AppShell.Main>
    </AppShell>
  );
}
