import { Stack, Title } from '@mantine/core';
import { HeroSettingsForm } from '../components/settings/HeroSettingsForm';
import { AboutSettingsForm } from '../components/settings/AboutSettingsForm';
import { ContactSettingsForm } from '../components/settings/ContactSettingsForm';
import { SocialSettingsForm } from '../components/settings/SocialSettingsForm';

// Une carte par section, chacune avec son propre formulaire et son propre bouton
// "Enregistrer" : chaque section a sa table dédiée côté backend (voir
// backend/src/settings) et s'enregistre indépendamment des autres — modifier
// l'accroche n'a par exemple aucun effet sur les coordonnées du studio, y compris en
// cas d'erreur de validation sur une autre section (voir docs/ANALYSE-PLAN-BACKEND.md,
// refonte du panneau admin du 26/08).
export function SettingsPage() {
  return (
    <Stack maw={900}>
      <Title order={2}>Réglages du site</Title>
      <HeroSettingsForm />
      <AboutSettingsForm />
      <ContactSettingsForm />
      <SocialSettingsForm />
    </Stack>
  );
}
