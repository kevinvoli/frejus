import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HeroSettings } from './entities/hero-settings.entity';
import { AboutSettings } from './entities/about-settings.entity';
import { ContactSettings } from './entities/contact-settings.entity';
import { SocialSettings } from './entities/social-settings.entity';
import { UpdateHeroSettingsDto } from './dto/update-hero-settings.dto';
import { UpdateAboutSettingsDto } from './dto/update-about-settings.dto';
import { UpdateContactSettingsDto } from './dto/update-contact-settings.dto';
import { UpdateSocialSettingsDto } from './dto/update-social-settings.dto';

const SETTINGS_ID = 1;

// Texte de départ, utilisé une seule fois si personne n'a encore rien saisi dans le
// panneau admin. Modifiable ensuite via PUT /settings/hero — jamais recodé en dur
// ailleurs.
const DEFAULT_HERO_TITLE = "Capturer l'instant, créer l'éternel";

// Le contenu éditable du site vitrine (accroche, à propos, coordonnées, réseaux) est
// réparti en 4 tables — une par section du panneau admin — plutôt qu'une seule table
// `site_settings` fourre-tout (voir docs/ANALYSE-PLAN-BACKEND.md, mise à jour du
// 26/08 sur la refonte du panneau admin : un formulaire indépendant par section,
// jusque dans la base de données). Le site vitrine, lui, continue de tout récupérer
// en un seul appel (`GET /settings`, voir get() ci-dessous) pour ne pas multiplier
// les requêtes publiques ni toucher aux composants du site vitrine.
@Injectable()
export class SettingsService {
  constructor(
    @InjectRepository(HeroSettings)
    private readonly heroRepo: Repository<HeroSettings>,
    @InjectRepository(AboutSettings)
    private readonly aboutRepo: Repository<AboutSettings>,
    @InjectRepository(ContactSettings)
    private readonly contactRepo: Repository<ContactSettings>,
    @InjectRepository(SocialSettings)
    private readonly socialRepo: Repository<SocialSettings>,
  ) {}

  // --- Section "Accueil" ---

  async getHero(): Promise<HeroSettings> {
    let settings = await this.heroRepo.findOne({ where: { id: SETTINGS_ID } });
    if (!settings) {
      settings = await this.heroRepo.save(
        this.heroRepo.create({
          id: SETTINGS_ID,
          heroTitle: DEFAULT_HERO_TITLE,
        }),
      );
    }
    return settings;
  }

  async updateHero(dto: UpdateHeroSettingsDto): Promise<HeroSettings> {
    const current = await this.getHero();
    return this.heroRepo.save(this.heroRepo.merge(current, dto));
  }

  // --- Section "À propos" ---

  async getAbout(): Promise<AboutSettings> {
    let settings = await this.aboutRepo.findOne({ where: { id: SETTINGS_ID } });
    if (!settings) {
      settings = await this.aboutRepo.save(
        this.aboutRepo.create({ id: SETTINGS_ID }),
      );
    }
    return settings;
  }

  async updateAbout(dto: UpdateAboutSettingsDto): Promise<AboutSettings> {
    const current = await this.getAbout();
    return this.aboutRepo.save(this.aboutRepo.merge(current, dto));
  }

  // --- Section "Studio et contact" ---

  async getContact(): Promise<ContactSettings> {
    let settings = await this.contactRepo.findOne({
      where: { id: SETTINGS_ID },
    });
    if (!settings) {
      settings = await this.contactRepo.save(
        this.contactRepo.create({ id: SETTINGS_ID }),
      );
    }
    return settings;
  }

  async updateContact(dto: UpdateContactSettingsDto): Promise<ContactSettings> {
    const current = await this.getContact();
    return this.contactRepo.save(this.contactRepo.merge(current, dto));
  }

  // --- Section "Réseaux sociaux" ---

  async getSocial(): Promise<SocialSettings> {
    let settings = await this.socialRepo.findOne({
      where: { id: SETTINGS_ID },
    });
    if (!settings) {
      settings = await this.socialRepo.save(
        this.socialRepo.create({ id: SETTINGS_ID }),
      );
    }
    return settings;
  }

  async updateSocial(dto: UpdateSocialSettingsDto): Promise<SocialSettings> {
    const current = await this.getSocial();
    return this.socialRepo.save(this.socialRepo.merge(current, dto));
  }

  // --- Agrégat public (site vitrine) ---

  // Fusionne les 4 sections dans la même forme plate qu'avant la refonte du panneau
  // admin : le site vitrine (Hero, About, Contact, Footer) n'a pas besoin de savoir
  // que ce contenu vient maintenant de 4 tables séparées, et continue de faire un
  // seul GET /settings comme avant.
  async get(): Promise<{
    heroTitle: string | null;
    heroSubtitle: string | null;
    heroImageUrl: string | null;
    aboutText: string | null;
    aboutImageUrl: string | null;
    studioName: string | null;
    address: string | null;
    city: string | null;
    phone: string | null;
    email: string | null;
    openingHours: string | null;
    instagramUrl: string | null;
    facebookUrl: string | null;
    pinterestUrl: string | null;
  }> {
    const [hero, about, contact, social] = await Promise.all([
      this.getHero(),
      this.getAbout(),
      this.getContact(),
      this.getSocial(),
    ]);
    return {
      heroTitle: hero.heroTitle,
      heroSubtitle: hero.heroSubtitle,
      heroImageUrl: hero.heroImageUrl,
      aboutText: about.aboutText,
      aboutImageUrl: about.aboutImageUrl,
      studioName: contact.studioName,
      address: contact.address,
      city: contact.city,
      phone: contact.phone,
      email: contact.email,
      openingHours: contact.openingHours,
      instagramUrl: social.instagramUrl,
      facebookUrl: social.facebookUrl,
      pinterestUrl: social.pinterestUrl,
    };
  }
}
